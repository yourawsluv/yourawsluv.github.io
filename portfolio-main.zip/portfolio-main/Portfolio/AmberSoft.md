---
tags:
  - Landing-page
  - Corporate
  - Website
  - Desktop
  - Mobile
Год: 2024
Релиз: true
Описание проекта: Корпоративный веб-сайт холдинга Ambercore
Ссылка: https://www.figma.com/design/mZq6FqGmvr4eLyLuvayZQ5/TON-Tigers?node-id=18-24946&t=IY18WkJRgIhIybLf-1
---

