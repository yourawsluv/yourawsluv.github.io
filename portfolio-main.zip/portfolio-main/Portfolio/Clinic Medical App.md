---
tags:
  - Software
  - System
  - CRM
  - Desktop
  - Mobile
Год: 2024
Релиз: 
Описание проекта: Клиентское и административное приложение для медицинских клиник
Ссылка: https://www.figma.com/design/YbUYgjHSbdNDqSPotkTkY4/Ambersoft-%2F-Medical-Clinic-App?node-id=34-5255&t=XYx5L8Yk2IpRVfhx-1
---
